gcc -pthread node.c
./a.out
