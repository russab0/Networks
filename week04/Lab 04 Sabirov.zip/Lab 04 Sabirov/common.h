#define MAXN 100

typedef struct _test_struct{
    char a[MAXN];
    unsigned int b;
    unsigned int c;
    	
} test_struct_t;


typedef struct result_struct_{

    char c[MAXN];

} result_struct_t;
